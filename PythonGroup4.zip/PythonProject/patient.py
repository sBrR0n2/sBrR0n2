# patient.py
import sqlite3

class Patient:
    def __init__(self, patient_id, name, age, contact):
        self.patient_id = patient_id
        self.name = name
        self.age = age
        self.contact = contact

    def __str__(self):
        return f"ID: {self.patient_id}, Name: {self.name}, Age: {self.age}, Contact: {self.contact}"

# Function to add a new patient to the database
def create_patient(db_file, name, age, contact):
    patient_id = f"P{get_new_patient_id(db_file):03d}"
    query = "INSERT INTO patients (patient_id, name, age, contact) VALUES (?, ?, ?, ?)"
    execute_query(query, (patient_id, name, age, contact), db_file)
    return patient_id

# Function to fetch all patients from the database
def get_patients(db_file):
    query = "SELECT * FROM patients"
    rows = fetch_all(query, db_file=db_file)
    return [Patient(patient_id, name, age, contact) for patient_id, name, age, contact in rows]

# Function to get the next available patient_id
def get_new_patient_id(db_file):
    query = "SELECT MAX(CAST(SUBSTR(patient_id, 2) AS INTEGER)) FROM patients"
    rows = fetch_all(query, db_file=db_file)
    return rows[0][0] + 1 if rows[0][0] else 1

# Helper functions for executing queries and fetching results
def execute_query(query, params=(), db_file='clinic_management.db'):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    conn.close()

def fetch_all(query, params=(), db_file='clinic_management.db'):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return rows
