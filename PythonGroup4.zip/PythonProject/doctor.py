# doctor.py
import sqlite3

class Doctor:
    def __init__(self, doctor_id, name, specialty):
        self.doctor_id = doctor_id
        self.name = name
        self.specialty = specialty

    def __str__(self):
        return f"Doctor ID: {self.doctor_id}, Name: {self.name}, Specialty: {self.specialty}"

# Function to add a new doctor to the database
def create_doctor(db_file, name, specialty):
    doctor_id = f"D{get_new_doctor_id(db_file):03d}"
    query = "INSERT INTO doctors (doctor_id, name, specialty) VALUES (?, ?, ?)"
    execute_query(query, (doctor_id, name, specialty), db_file)
    return doctor_id

# Function to fetch all doctors from the database
def get_doctors(db_file):
    query = "SELECT * FROM doctors"
    rows = fetch_all(query, db_file=db_file)
    return [Doctor(doctor_id, name, specialty) for doctor_id, name, specialty in rows]

# Function to get the next available doctor_id
def get_new_doctor_id(db_file):
    query = "SELECT MAX(CAST(SUBSTR(doctor_id, 2) AS INTEGER)) FROM doctors"
    rows = fetch_all(query, db_file=db_file)
    return rows[0][0] + 1 if rows[0][0] else 1

# Helper functions for executing queries and fetching results
def execute_query(query, params=(), db_file='clinic_management.db'):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    conn.close()

def fetch_all(query, params=(), db_file='clinic_management.db'):
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return rows
