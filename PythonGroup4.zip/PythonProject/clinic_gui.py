import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime
import re
import sqlite3

# Database Setup
def setup_database():
    """Create the SQLite database and tables if they don't already exist."""
    conn = sqlite3.connect('clinic_management.db')
    cursor = conn.cursor()

    # Create tables for Patients, Appointments, and Doctors
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS patients (
        patient_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        age INTEGER NOT NULL,
        contact TEXT NOT NULL
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS appointments (
        appointment_id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS doctors (
        doctor_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        specialty TEXT NOT NULL
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS doctor_reports (
        report_id TEXT PRIMARY KEY,
        doctor_id TEXT NOT NULL,
        patient_id TEXT NOT NULL,
        date TEXT NOT NULL,
        report_details TEXT NOT NULL,
        FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id),
        FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
    )
    ''')

    conn.commit()
    conn.close()

# Patient, Appointment, Doctor, and DoctorReport classes
class Patient:
    def __init__(self, patient_id, name, age, contact):
        self.patient_id = patient_id
        self.name = name
        self.age = age
        self.contact = contact

    def __str__(self):
        return f"ID: {self.patient_id}, Name: {self.name}, Age: {self.age}, Contact: {self.contact}"

class Appointment:
    def __init__(self, appointment_id, patient_id, date, time):
        self.appointment_id = appointment_id
        self.patient_id = patient_id
        self.date = date
        self.time = time

    def __str__(self):
        return f"Appointment ID: {self.appointment_id}, Patient ID: {self.patient_id}, Date: {self.date}, Time: {self.time}"

class Doctor:
    def __init__(self, doctor_id, name, specialty):
        self.doctor_id = doctor_id
        self.name = name
        self.specialty = specialty

    def __str__(self):
        return f"Doctor ID: {self.doctor_id}, Name: {self.name}, Specialty: {self.specialty}"

class DoctorReport:
    def __init__(self, report_id, doctor_id, patient_id, date, report_details):
        self.report_id = report_id
        self.doctor_id = doctor_id
        self.patient_id = patient_id
        self.date = date
        self.report_details = report_details

    def __str__(self):
        return f"Report ID: {self.report_id}, Doctor ID: {self.doctor_id}, Patient ID: {self.patient_id}, Date: {self.date}, Report: {self.report_details}"

# Clinic Management System
class ClinicManagementSystem:
    def __init__(self):
        self.db_file = 'clinic_management.db'
        setup_database()
        self.patient_counter = 1
        self.appointment_counter = 1
        self.doctor_counter = 1
        self.report_counter = 1

    def add_patient(self, name, age, contact):
        patient_id = f"P{self.patient_counter:03d}"
        self.patient_counter += 1
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO patients (patient_id, name, age, contact)
        VALUES (?, ?, ?, ?)
        ''', (patient_id, name, age, contact))
        conn.commit()
        conn.close()
        return patient_id

    def schedule_appointment(self, patient_id, date, time):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM patients WHERE patient_id = ?', (patient_id,))
        patient = cursor.fetchone()
        if not patient:
            conn.close()
            raise ValueError("Patient ID not found.")

        if not self.is_valid_date(date) or not self.is_valid_time(time):
            conn.close()
            raise ValueError("Invalid date or time format.")

        cursor.execute('SELECT * FROM appointments WHERE date = ? AND time = ?', (date, time))
        if cursor.fetchone():
            conn.close()
            raise ValueError("Appointment conflict.")

        appointment_id = f"A{self.appointment_counter:03d}"
        self.appointment_counter += 1
        cursor.execute('''
        INSERT INTO appointments (appointment_id, patient_id, date, time)
        VALUES (?, ?, ?, ?)
        ''', (appointment_id, patient_id, date, time))
        conn.commit()
        conn.close()
        return appointment_id

    def add_doctor(self, name, specialty):
        doctor_id = f"D{self.doctor_counter:03d}"
        self.doctor_counter += 1
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO doctors (doctor_id, name, specialty)
        VALUES (?, ?, ?)
        ''', (doctor_id, name, specialty))
        conn.commit()
        conn.close()
        return doctor_id

    def add_doctor_report(self, doctor_id, patient_id, date, report_details):
        report_id = f"R{self.report_counter:03d}"
        self.report_counter += 1
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO doctor_reports (report_id, doctor_id, patient_id, date, report_details)
        VALUES (?, ?, ?, ?, ?)
        ''', (report_id, doctor_id, patient_id, date, report_details))
        conn.commit()
        conn.close()
        return report_id

    def get_patients(self):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM patients')
        patients = cursor.fetchall()
        conn.close()
        return [Patient(patient_id, name, age, contact) for patient_id, name, age, contact in patients]

    def get_appointments(self):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM appointments')
        appointments = cursor.fetchall()
        conn.close()
        return [Appointment(appointment_id, patient_id, date, time) for appointment_id, patient_id, date, time in appointments]

    def get_doctors(self):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM doctors')
        doctors = cursor.fetchall()
        conn.close()
        return [Doctor(doctor_id, name, specialty) for doctor_id, name, specialty in doctors]

    def get_reports(self):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM doctor_reports')
        reports = cursor.fetchall()
        conn.close()
        return [DoctorReport(report_id, doctor_id, patient_id, date, report_details) for report_id, doctor_id, patient_id, date, report_details in reports]

    def is_valid_date(self, date):
        try:
            datetime.strptime(date, "%Y-%m-%d")
            return True
        except ValueError:
            return False

    def is_valid_time(self, time):
        return bool(re.match(r"^(?:[01]\d|2[0-3]):([0-5]\d)$", time))

# Admin login class
class AdminLogin:
    def __init__(self, root, system):
        self.system = system
        self.root = root
        self.root.title("Admin Login")
        self.root.geometry("350x250")
        self.root.config(bg="#f4f4f4")

        self.apply_styles()

        self.username_label = ttk.Label(self.root, text="Username:", font=("Helvetica", 12), background="#f4f4f4")
        self.username_label.pack(pady=10)

        self.username_entry = ttk.Entry(self.root, font=("Helvetica", 12), foreground="black", background="white")
        self.username_entry.pack(pady=10)

        self.password_label = ttk.Label(self.root, text="Password:", font=("Helvetica", 12), background="#f4f4f4")
        self.password_label.pack(pady=10)

        self.password_entry = ttk.Entry(self.root, show="*", font=("Helvetica", 12), foreground="black", background="white")
        self.password_entry.pack(pady=10)

        self.login_button = ttk.Button(self.root, text="Login", command=self.authenticate)
        self.login_button.pack(pady=15)

    def apply_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("TButton", font=("Helvetica", 12), background="#66b3ff", foreground="black", padding=10, relief="flat")
        style.map("TButton", background=[("active", "#3385ff")])

        style.configure("TEntry", font=("Helvetica", 12), padding=5, fieldbackground="white", foreground="black")

    def authenticate(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if username == "root" and password == "password":
            self.root.destroy()
            self.open_enter_page()
        else:
            messagebox.showerror("Login Failed", "Invalid credentials. Please try again.")

    def open_enter_page(self):
        enter_page = tk.Tk()
        enter_page.title("Clinic Management System")
        enter_page.geometry("350x200")
        enter_page.config(bg="#f4f4f4")

        self.apply_styles()

        ttk.Label(enter_page, text="Welcome to the Clinic Management System", font=("Helvetica", 12), background="#f4f4f4").pack(pady=20)
        
        enter_button = ttk.Button(enter_page, text="Enter", command=self.open_main_gui)
        enter_button.pack(pady=10)

        enter_page.mainloop()

    def open_main_gui(self):
        root = tk.Tk()
        app = ClinicGUI(root, self.system)
        root.mainloop()

# GUI Implementation
class ClinicGUI:
    def __init__(self, root, system):
        self.system = system
        self.root = root
        self.root.title("Clinic Management System")
        self.root.geometry("800x600")
        self.root.config(bg="#f4f4f4")

        # Apply styles
        self.apply_styles()

        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root, width=800, height=600)
        self.notebook.pack(fill="both", expand=True)

        # Create tabs
        self.create_patient_tab()
        self.create_appointment_tab()
        self.create_doctor_tab()  # Add Doctor tab
        self.create_view_tabs()
        self.create_help_tab()  # Add Help and Support tab

    def apply_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("TNotebook", background="#f4f4f4", tabmargins=[2, 5, 2, 0])
        style.configure("TNotebook.Tab", background="#f4f4f4", padding=[12, 8], font=("Helvetica", 14), foreground="black")
        style.map("TNotebook.Tab", background=[("selected", "#3385ff")], foreground=[("selected", "white")])

        style.configure("TButton", font=("Helvetica", 12), background="#66b3ff", foreground="black", padding=10, relief="flat")
        style.map("TButton", background=[("active", "#3385ff")])

        style.configure("TEntry", font=("Helvetica", 12), padding=5, fieldbackground="white", foreground="black")

    def create_patient_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Add Patient")

        ttk.Label(frame, text="Name:", font=("Helvetica", 12)).grid(row=0, column=0, padx=15, pady=10, sticky="w")
        ttk.Label(frame, text="Age:", font=("Helvetica", 12)).grid(row=1, column=0, padx=15, pady=10, sticky="w")
        ttk.Label(frame, text="Contact:", font=("Helvetica", 12)).grid(row=2, column=0, padx=15, pady=10, sticky="w")

        self.name_entry = ttk.Entry(frame)
        self.age_entry = ttk.Entry(frame)
        self.contact_entry = ttk.Entry(frame)

        self.name_entry.grid(row=0, column=1, padx=15, pady=10, sticky="ew")
        self.age_entry.grid(row=1, column=1, padx=15, pady=10, sticky="ew")
        self.contact_entry.grid(row=2, column=1, padx=15, pady=10, sticky="ew")

        ttk.Button(frame, text="Add Patient", command=self.add_patient).grid(row=3, column=0, columnspan=2, pady=15)

    def add_patient(self):
        name = self.name_entry.get()
        age = self.age_entry.get()
        contact = self.contact_entry.get()

        try:
            if not name or not contact:
                raise ValueError("Name and contact must not be empty.")
            
            patient_id = self.system.add_patient(name, age, contact)
            messagebox.showinfo("Success", f"Patient added successfully with ID: {patient_id}")
            
            self.name_entry.delete(0, tk.END)
            self.age_entry.delete(0, tk.END)
            self.contact_entry.delete(0, tk.END)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def create_appointment_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Schedule Appointment")

        ttk.Label(frame, text="Patient ID:", font=("Helvetica", 12)).grid(row=0, column=0, padx=15, pady=10, sticky="w")
        ttk.Label(frame, text="Date (YYYY-MM-DD):", font=("Helvetica", 12)).grid(row=1, column=0, padx=15, pady=10, sticky="w")
        ttk.Label(frame, text="Time (HH:MM):", font=("Helvetica", 12)).grid(row=2, column=0, padx=15, pady=10, sticky="w")

        self.patient_id_entry = ttk.Entry(frame)
        self.date_entry = ttk.Entry(frame)
        self.time_entry = ttk.Entry(frame)

        self.patient_id_entry.grid(row=0, column=1, padx=15, pady=10, sticky="ew")
        self.date_entry.grid(row=1, column=1, padx=15, pady=10, sticky="ew")
        self.time_entry.grid(row=2, column=1, padx=15, pady=10, sticky="ew")

        ttk.Button(frame, text="Schedule Appointment", command=self.schedule_appointment).grid(row=3, column=0, columnspan=2, pady=15)

    def schedule_appointment(self):
        patient_id = self.patient_id_entry.get()
        date = self.date_entry.get()
        time = self.time_entry.get()

        try:
            appointment_id = self.system.schedule_appointment(patient_id, date, time)
            messagebox.showinfo("Success", f"Appointment scheduled with ID: {appointment_id}")
            
            self.patient_id_entry.delete(0, tk.END)
            self.date_entry.delete(0, tk.END)
            self.time_entry.delete(0, tk.END)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def create_doctor_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Add Doctor")

        ttk.Label(frame, text="Doctor Name:", font=("Helvetica", 12)).grid(row=0, column=0, padx=15, pady=10, sticky="w")
        ttk.Label(frame, text="Specialty:", font=("Helvetica", 12)).grid(row=1, column=0, padx=15, pady=10, sticky="w")

        self.doctor_name_entry = ttk.Entry(frame)
        self.specialty_entry = ttk.Entry(frame)

        self.doctor_name_entry.grid(row=0, column=1, padx=15, pady=10, sticky="ew")
        self.specialty_entry.grid(row=1, column=1, padx=15, pady=10, sticky="ew")

        ttk.Button(frame, text="Add Doctor", command=self.add_doctor).grid(row=2, column=0, columnspan=2, pady=15)

    def add_doctor(self):
        name = self.doctor_name_entry.get()
        specialty = self.specialty_entry.get()

        try:
            if not name or not specialty:
                raise ValueError("Doctor name and specialty must not be empty.")
            
            doctor_id = self.system.add_doctor(name, specialty)
            messagebox.showinfo("Success", f"Doctor added successfully with ID: {doctor_id}")
            
            self.doctor_name_entry.delete(0, tk.END)
            self.specialty_entry.delete(0, tk.END)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def create_view_tabs(self):
        self.view_patients_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.view_patients_tab, text="View Patients")

        self.view_appointments_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.view_appointments_tab, text="View Appointments")

        self.view_doctors_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.view_doctors_tab, text="View Doctors")

        self.patient_tree = ttk.Treeview(self.view_patients_tab, columns=("Patient ID", "Name", "Age", "Contact"), show="headings")
        self.patient_tree.heading("Patient ID", text="Patient ID")
        self.patient_tree.heading("Name", text="Name")
        self.patient_tree.heading("Age", text="Age")
        self.patient_tree.heading("Contact", text="Contact")
        self.patient_tree.pack(padx=15, pady=15, fill="both", expand=True)

        self.appointment_tree = ttk.Treeview(self.view_appointments_tab, columns=("Appointment ID", "Patient ID", "Date", "Time"), show="headings")
        self.appointment_tree.heading("Appointment ID", text="Appointment ID")
        self.appointment_tree.heading("Patient ID", text="Patient ID")
        self.appointment_tree.heading("Date", text="Date")
        self.appointment_tree.heading("Time", text="Time")
        self.appointment_tree.pack(padx=15, pady=15, fill="both", expand=True)

        self.doctor_tree = ttk.Treeview(self.view_doctors_tab, columns=("Doctor ID", "Name", "Specialty"), show="headings")
        self.doctor_tree.heading("Doctor ID", text="Doctor ID")
        self.doctor_tree.heading("Name", text="Name")
        self.doctor_tree.heading("Specialty", text="Specialty")
        self.doctor_tree.pack(padx=15, pady=15, fill="both", expand=True)

        ttk.Button(self.view_patients_tab, text="Refresh", command=self.refresh_patients).pack(pady=15)
        ttk.Button(self.view_appointments_tab, text="Refresh", command=self.refresh_appointments).pack(pady=15)
        ttk.Button(self.view_doctors_tab, text="Refresh", command=self.refresh_doctors).pack(pady=15)

    def refresh_patients(self):
        for row in self.patient_tree.get_children():
            self.patient_tree.delete(row)
        
        for patient in self.system.get_patients():
            self.patient_tree.insert("", "end", values=(patient.patient_id, patient.name, patient.age, patient.contact))

    def refresh_appointments(self):
        for row in self.appointment_tree.get_children():
            self.appointment_tree.delete(row)

        for appointment in self.system.get_appointments():
            self.appointment_tree.insert("", "end", values=(appointment.appointment_id, appointment.patient_id, appointment.date, appointment.time))

    def refresh_doctors(self):
        for row in self.doctor_tree.get_children():
            self.doctor_tree.delete(row)

        for doctor in self.system.get_doctors():
            self.doctor_tree.insert("", "end", values=(doctor.doctor_id, doctor.name, doctor.specialty))

    def create_help_tab(self):
        help_frame = ttk.Frame(self.notebook)
        self.notebook.add(help_frame, text="Help and Support")

        help_text = """
        1. To add a patient, enter the patient's details in the 'Add Patient' tab and click 'Add Patient'.
        2. To schedule an appointment, enter the patient ID, date (YYYY-MM-DD), and time (HH:MM) in the 'Schedule Appointment' tab.
        3. To view patients, appointments, or doctors, navigate to the 'View Patients', 'View Appointments', or 'View Doctors' tabs.

        Troubleshooting:
        - Ensure you enter valid date and time formats.
        - If you encounter an error, check for missing fields or invalid formats.
        """
        
        ttk.Label(help_frame, text="Help and Support", font=("Helvetica", 16, "bold")).pack(pady=10)
        ttk.Label(help_frame, text=help_text, font=("Helvetica", 12)).pack(padx=20, pady=10)


if __name__ == "__main__":
    system = ClinicManagementSystem()
    root = tk.Tk()
    admin_login = AdminLogin(root, system)
    root.mainloop()